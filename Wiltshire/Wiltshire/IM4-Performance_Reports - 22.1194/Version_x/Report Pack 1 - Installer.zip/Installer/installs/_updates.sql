--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\HIG_MODULES.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\HIG_MODULES.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\hig_module_roles.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\hig_module_roles.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\im_pods.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\im_pods.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\im_pod_sql.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\im_pod_sql.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\im_pod_chart.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\im_pod_chart.sql
SET FEEDBACK OFF
--
--
