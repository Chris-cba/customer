--	**** 2.14 *****
--	IM_CITYFI_NWLW_TOP

  select
  (select q'{<a href="javascript:doDrillDown('IM_CITYFI_NWLW_DD1', 'to_number(trunc(sysdate)- to_date('01-01-1900', 'MM-DD-YYYY'))}'  ||q'{');"><font face="verdana" color="blue"><u>}'|| 'Notices With Late Warnings Interactive Report - Full' ||q'{</u></font></a>}'  from dual) "Report"
  ,(select q'{<a href="javascript:doDrillDown('IM_CITYFI_NWLW_DD1', '360}'  ||q'{');"><font face="verdana" color="blue"><u>}'|| 'Last 360 Days' ||q'{</u></font></a>}' from dual) "Report360"
  ,(select q'{<a href="javascript:doDrillDown('IM_CITYFI_NWLW_DD1', '180}'  ||q'{');"><font face="verdana" color="blue"><u>}'|| 'Last 180 Days' ||q'{</u></font></a>}' from dual) "Report180"
  ,(select q'{<a href="javascript:doDrillDown('IM_CITYFI_NWLW_DD1', '90}'  ||q'{');"><font face="verdana" color="blue"><u>}'|| 'Last 90 Days' ||q'{</u></font></a>}' from dual) "Report90"    
  ,(select q'{<a href="javascript:doDrillDown('IM_CITYFI_NWLW_DD1', '30}'  ||q'{');"><font face="verdana" color="blue"><u>}'|| 'Last 30 Days' ||q'{</u></font></a>}' from dual) "Report30"
  from dual
  
  
  
  
  
  
  
  --	IM_CITYFI_NWLW_DD1
  SELECT 
  O103470.NOTICE_TYPE, O103470.WORKS_REFERENCE, ( O103470.CREATED_DATE )
  , O103470.CREATED_BY, O103470.NOTICE_SEQUENCE_NUMBER, O103470.PHASE_NUMBER
  , O103470.STREET_NAME, O103470.STREET_LOCAILITY, O103470.STREET_TOWN
  , O103470.STREET_NAMING_AUTHORITY, O103470.NOTICE_COMMENTS
  , O103470.WORKS_CATEGORY_DESCRIPTION, O103470.PROMOTER_NAME
  , O103470.CONTRACTOR_NAME, O103881.ERROR_SEQUENCE
  , O103881.NOTICE_ERROR_TEXT, O103881.VALIDATION_ERROR_ID
  , O103881.ERROR_TEXT, O107444.EXTERNAL_REFERENCE
FROM EXOR.IMF_TMA_NOTICES O103470, EXOR.IMF_TMA_NOTICE_ERRORS O103881, EXOR.IMF_TMA_WORKS O107444
WHERE ( ( O107444.WORKS_ID = O103470.WORKS_ID )AND ( O103881.NOTICE_ID = O103470.NOTICE_ID ) ) 
AND ( ( O103470.CREATED_DATE ) >=sysdate - to_number(:P6_PARAM1)) 
AND ( O103881.VALIDATION_ERROR_ID IN (18,118,119,21,113,112) )
ORDER BY O103470.WORKS_REFERENCE ASC, O103470.NOTICE_SEQUENCE_NUMBER ASC, O103881.ERROR_SEQUENCE ASC
