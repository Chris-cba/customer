Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('L', 'RSD', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('L', 'RSAM', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('L', 'RSDE', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('L', 'RSIC', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('L', 'RSIS', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('L', 'RSRE', 'N', to_date('01-JAN-1901'));
