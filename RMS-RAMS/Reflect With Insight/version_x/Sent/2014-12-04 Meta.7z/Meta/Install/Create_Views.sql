exec nm3inv.create_view ('RSD', false);
exec nm3inv.create_view ('RSAM', false);
exec nm3inv.create_view ('RSDE', false);
exec nm3inv.create_view ('RSIC', false);
exec nm3inv.create_view ('RSIS', false);
exec nm3inv.create_view ('RSRE', false);

exec nm3inv.create_view ('RSD', true);
exec nm3inv.create_view ('RSAM', true);
exec nm3inv.create_view ('RSDE', true);
exec nm3inv.create_view ('RSIC', true);
exec nm3inv.create_view ('RSIS', true);
exec nm3inv.create_view ('RSRE', true);
