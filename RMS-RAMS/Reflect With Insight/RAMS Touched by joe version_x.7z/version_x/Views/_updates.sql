
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\Create_Asset_Themes.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\Create_Asset_Themes.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\requestss_during_a_period_sdo.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\requestss_during_a_period_sdo.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\xrms_context_rpt_dates.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\xrms_context_rpt_dates.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\accomplishments_during_a_period.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\accomplishments_during_a_period.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\accomplishments_during_a_period_sdo.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\accomplishments_during_a_period_sdo.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\defects_during_a_period.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\defects_during_a_period.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\defects_during_a_period_sdo.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\defects_during_a_period_sdo.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\inspections_during_a_period.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\inspections_during_a_period.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\inspections_during_a_period_sdo.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\inspections_during_a_period_sdo.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\performance_during_a_selected_period.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\performance_during_a_selected_period.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\sql\requestss_during_a_period.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\sql\requestss_during_a_period.sql
SET FEEDBACK OFF
--
--
