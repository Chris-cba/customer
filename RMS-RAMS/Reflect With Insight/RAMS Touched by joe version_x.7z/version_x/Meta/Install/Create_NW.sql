Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('LCWY', 'RSD', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('LCWY', 'RSAM', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('LCWY', 'RSDE', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('LCWY', 'RSIC', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('LCWY', 'RSIN', 'N', to_date('01-JAN-1901'));
Insert Into nm_inv_nw_all (NIN_NW_TYPE, NIN_NIT_INV_CODE, NIN_LOC_MANDATORY, NIN_START_DATE) Values ('LCWY', 'RSRE', 'N', to_date('01-JAN-1901'));

commit;