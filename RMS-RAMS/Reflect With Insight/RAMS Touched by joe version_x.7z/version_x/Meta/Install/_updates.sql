SET TERM ON
PROMPT *** RUNNING: Create_Domain.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_Domain.sql
SET FEEDBACK OFF

--
--
SET TERM ON
PROMPT *** RUNNING: Create_Assets.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_Assets.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: Create_Attribs.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_Attribs.sql
SET FEEDBACK OFF
--

--
--
--
SET TERM ON
PROMPT *** RUNNING: Create_NW.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_NW.sql
SET FEEDBACK OFF
--

--

SET TERM ON
PROMPT *** RUNNING: Create_Groupings.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_Groupings.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: Create_Roles.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_Roles.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: Create_Views.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START Create_Views.sql
SET FEEDBACK OFF
--
--
