--
--------------------------------------------------------------------------------
--   PVCS Identifiers :-
--
--       sccsid           : $Header:$
--       Module Name      : $Workfile:$
--       Date into PVCS   : $Date:$
--       Date fetched Out : $Modtime:$
--       PVCS Version     : $Revision:$
--
--------------------------------------------------------------------------------
--

PROMPT Delete System Option WORKFOLDER and Values

DELETE hig_user_options
 WHERE huo_id = 'WORKFOLDER';

DELETE hig_option_values
 WHERE hov_id = 'WORKFOLDER';
 
DELETE hig_option_list
 WHERE hol_id = 'WORKFOLDER';
 
DELETE hig_option_list 
 WHERE hol_id='DIRMOVE';
 
DELETE hig_option_values
 WHERE hov_id = 'DIRMOVE';

PROMPT Drop table DOC_FILE_LOCKS

DROP TABLE doc_file_locks CASCADE CONSTRAINTS;

PROMPT Drop table DOC_LOCATION_TABLES

DROP TABLE doc_location_tables CASCADE CONSTRAINTS;

PROMPT Drop table DOC_FILES_ALL

DROP TABLE doc_files_all CASCADE CONSTRAINTS;

PROMPT Drop WEBUTIL_DB Package

DROP PACKAGE webutil_db;

PROMPT Drop NM3DOC_FILES Package

DROP PACKAGE nm3doc_files;

DROP Sequence dlt_id_seq

DROP SEQUENCE dlt_id_seq;

PROMPT Drop synonyms

BEGIN
  nm3ddl.drop_synonym_for_object('DOC_FILES_ALL');
  nm3ddl.drop_synonym_for_object('DOC_FILE_LOCKS');
  nm3ddl.drop_synonym_for_object('DOC_LOCATION_TABLES');
  nm3ddl.drop_synonym_for_object('WEBUTIL_DB');
  nm3ddl.drop_synonym_for_object('NM3DOC_FILES');
END;
/



