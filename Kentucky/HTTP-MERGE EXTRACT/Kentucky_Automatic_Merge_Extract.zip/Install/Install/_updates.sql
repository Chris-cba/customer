--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xor_merge_extract.pks ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xor_merge_extract.pks
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\XOR_MERGE_EXTRACT.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\XOR_MERGE_EXTRACT.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\merge_extract_data1.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\merge_extract_data1.sql
SET FEEDBACK OFF
--
--
