--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\Hath.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\Hath.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_META_Insert.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_META_Insert.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_META_Insert.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_META_Insert.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_hath_fk.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_hath_fk.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\HATH_TRIG.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\HATH_TRIG.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\HATH_TRIG_insert.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\HATH_TRIG_insert.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\HATT_TRIG.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\HATT_TRIG.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\HATT_TRIG_insert.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\HATT_TRIG_insert.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\Hath_CSV_LOAD.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\Hath_CSV_LOAD.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\Hatt_CSV_LOAD.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\Hatt_CSV_LOAD.sql
SET FEEDBACK OFF
--
--
