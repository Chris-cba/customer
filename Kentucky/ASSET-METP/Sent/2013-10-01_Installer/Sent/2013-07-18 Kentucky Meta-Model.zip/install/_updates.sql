--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METP.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METP.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_META_Insert.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_META_Insert.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_META_Insert.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_META_Insert.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_METP_fk.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_METP_fk.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METP_TRIG.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METP_TRIG.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METP_TRIG_insert.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METP_TRIG_insert.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METC_TRIG.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METC_TRIG.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METC_TRIG_insert.SQL ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METC_TRIG_insert.SQL
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METP_CSV_LOAD.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METP_CSV_LOAD.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METC_CSV_LOAD.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METC_CSV_LOAD.sql
SET FEEDBACK OFF
--
--
