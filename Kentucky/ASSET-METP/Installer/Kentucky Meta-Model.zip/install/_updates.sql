--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METP.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METP.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_META_Insert.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_META_Insert.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_META_Insert.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_META_Insert.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xKYCT_METP_fk.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xKYCT_METP_fk.sql
SET FEEDBACK OFF
--
--
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\table_x_xnminvitemsall_metc.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\table_x_xnminvitemsall_metc.sql
SET FEEDBACK OFF
--
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_xnminvitemsall_metc.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_xnminvitemsall_metc.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\MetC_compound.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\MetC_compound.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\MetP_compound.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\MetP_compound.sql
SET FEEDBACK OFF
--
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METP_CSV_LOAD.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METP_CSV_LOAD.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\METC_CSV_LOAD.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\METC_CSV_LOAD.sql
SET FEEDBACK OFF
--
--
