
--sys context for xaa_route_all
create or replace context xaa_eff_date_context using xky_hig_to_aa;