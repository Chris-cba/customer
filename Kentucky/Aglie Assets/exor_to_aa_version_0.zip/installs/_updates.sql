--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\xaa_route_temp.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\xaa_route_temp.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\XAA_SPATIAL_AUDIT.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\XAA_SPATIAL_AUDIT.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\xaa_asset_type.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\xaa_asset_type.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\xaa_length_change.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\xaa_length_change.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\xaa_loc_ident_net_ref.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\xaa_loc_ident_net_ref.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\xaa_route_sdo.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\xaa_route_sdo.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\xaa_route.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\xaa_route.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\xaa_route_all.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\xaa_route_all.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\triggers\xaa_SPATIAL_AUDIT_trg.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\triggers\xaa_SPATIAL_AUDIT_trg.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\x_log_table.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\x_log_table.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\x_log_table.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\x_log_table.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xky_hig_to_aa.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xky_hig_to_aa.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xky_hig_to_aa.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xky_hig_to_aa.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xky_hig_to_aa.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xky_hig_to_aa.sql
SET FEEDBACK OFF
--
--

