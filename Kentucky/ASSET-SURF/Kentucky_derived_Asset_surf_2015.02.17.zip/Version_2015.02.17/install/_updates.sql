--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\NM_INV_ATTRI_LOOKUP_ALL.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\NM_INV_ATTRI_LOOKUP_ALL.sql
SET FEEDBACK OFF
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\nm_inv_types.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\nm_inv_types.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\nm_inv_type_attribs_all.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\nm_inv_type_attribs_all.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\nm_inv_type_x.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\nm_inv_type_x.sql
SET FEEDBACK OFF
--

--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\NM_MRG_query.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\NM_MRG_query.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_tab_surf_lookup.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_tab_surf_lookup.sql
SET FEEDBACK OFF
--
--SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_surf_LOOKUP.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_surf_LOOKUP.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\DerivedAsset.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\DerivedAsset.sql
SET FEEDBACK OFF
--
--
----------Admin_Unit_issue

SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\admin_unit_issue\xky_surf_au.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\admin_unit_issue\xky_surf_au.sql
SET FEEDBACK OFF

SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\admin_unit_issue\zz_proceedure_to_update_au.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\admin_unit_issue\zz_proceedure_to_update_au.sql
SET FEEDBACK OFF