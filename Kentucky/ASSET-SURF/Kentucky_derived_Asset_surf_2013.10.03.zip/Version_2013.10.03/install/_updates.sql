--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\NM_INV_ATTRI_LOOKUP_ALL.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\NM_INV_ATTRI_LOOKUP_ALL.sql
SET FEEDBACK OFF
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\nm_inv_types.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\nm_inv_types.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\nm_inv_type_attribs_all.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\nm_inv_type_attribs_all.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\nm_inv_type_x.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\nm_inv_type_x.sql
SET FEEDBACK OFF
--

--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\NM_MRG_query.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\NM_MRG_query.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_tab_surf_lookup.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_tab_surf_lookup.sql
SET FEEDBACK OFF
--
--SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_surf_LOOKUP.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_surf_LOOKUP.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\DerivedAsset.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\DerivedAsset.sql
SET FEEDBACK OFF
--
--

