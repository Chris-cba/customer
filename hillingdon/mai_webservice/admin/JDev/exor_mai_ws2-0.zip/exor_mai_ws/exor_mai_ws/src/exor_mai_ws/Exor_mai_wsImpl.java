package exor_mai_ws;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.sql.DataSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import org.xml.sax.SAXException;

public class Exor_mai_wsImpl
{
  //Shared Database Connection Object.
  private Connection con = null;

  public Exor_mai_wsImpl()
  {
  }

//
//Web Service Operation Methods.
//

  /**
   *
   * @webmethod
   */
  public Element GetAdminUnits(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_admin_units;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAdminUnits

  /**
   *
   * @webmethod
   */
  public Element GetAdminGroups(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_admin_groups;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAdminGroups

  /**
   *
   * @webmethod
   */
  public Element GetUsers(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_users;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetUsers

  /**
   *
   * @webmethod
   */
  public Element GetRoadSections(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_road_sections;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetRoadSections

  /**
   *
   * @webmethod
   */
  public Element GetAssetTypes(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_asset_types;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAssetTypes

  /**
   *
   * @webmethod
   */
  public Element GetAssetTypeAttribs(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_asset_type_attribs;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAssetTypeAttribs

  /**
   *
   * @webmethod
   */
  public Element GetAssetIDs(Element input)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Convert the input Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String inputSTR = ElementToString(input).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_asset_ids(XMLTYPE('"+ inputSTR +"'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAssetIDs

  /**
   *
   * @webmethod
   */
  public Element GetModifiedAssetIDs(Element input)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Convert the input Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String inputSTR = ElementToString(input).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_modified_asset_ids(XMLTYPE('"+ inputSTR +"'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetModifiedAssetIDs

  /**
   *
   * @webmethod
   */
  public Element GetAssetDetails(Element input)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Convert the input Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String inputSTR = ElementToString(input).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_asset_details(XMLTYPE('"+ inputSTR +"'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAssetDetails

  /**
   *
   * @webmethod
   */
  public Element GetSDFlags(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_sd_flags;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetSDFlags

  /**
   *
   * @webmethod
   */
  public Element GetInitiationTypes(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_initiation_types;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetInitiationTypes

  /**
   *
   * @webmethod
   */
  public Element GetNWActivities(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_nw_activities;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetNWActivities

  /**
   *
   * @webmethod
   */
  public Element GetAssetActivities(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_asset_activities;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetAssetActivities

  /**
   *
   * @webmethod
   */
  public Element GetDefectTypes(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_defect_codes;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetDefectTypes

  /**
   *
   * @webmethod
   */
  public Element GetSISSCodes(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_siss_codes;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetSISSCodes

  /**
   *
   * @webmethod
   */
  public Element GetPriorities(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_priorities;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetPriorities

  /**
   *
   * @webmethod
   */
  public Element GetNotifyOrgs(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_notify_orgs;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetNotifyOrgs

  /**
   *
   * @webmethod
   */
  public Element GetRechargeOrgs(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_recharge_orgs;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetRechargeOrgs

  /**
   *
   * @webmethod
   */
  public Element GetRepairTypes(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_repair_types;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetRepairTypes

  /**
   *
   * @webmethod
   */
  public Element GetTreatments(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_treatments;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetTreatments

  /**
   *
   * @webmethod
   */
  public Element GetStandardItems(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_standard_items;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetStandardItems

  /**
   *
   * @webmethod
   */
  public Element GetContracts(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_contracts;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetContracts

  /**
   *
   * @webmethod
   */
  public Element GetSchemeTypes(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_scheme_types;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetSchemeTypes

  /**
   *
   * @webmethod
   */
  public Element GetCurrentBudgets(Element dummy)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_current_budgets;"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetCurrentBudgets

  /**
   *
   * @webmethod
   */
  public Element GetRoadGroupSectionIDs(Element input)
  throws Exception
  {
    //Define the return Element
    Element retval = null;

    try
    {
      //Convert the input Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String inputSTR = ElementToString(input).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE "
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.get_road_group_section_ids(XMLTYPE('"+ inputSTR +"'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
                   ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);

    } catch (Throwable t) {
      throw printException(t);
    }

    //Return the Output.
    return retval;

  } //GetRoadGroupSectionIDs

  /**
   *
   * @webmethod
   */
  public Element CreateAdhocDefect(Element defect)
  throws Exception
  {
    //Define the return Element
    Element retval = null;
    
    try
    {
      //Convert the defect Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String input = ElementToString(defect).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE"
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.create_adhoc_defect(XMLTYPE('" + input + "'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
               ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);
    } catch (Throwable t) {
      throw printException(t);
    }

    return retval;

  } //CreateAdhocDefect

  /**
   *
   * @webmethod
   */
  public Element CreateDefectWorkOrder(Element defectWorkOrder)
  throws Exception
  {
    //Define the return Element
    Element retval = null;
    
    try
    {
      //Convert the defectWorkOrder Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String input = ElementToString(defectWorkOrder).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE"
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.create_defect_work_order(XMLTYPE('" + input + "'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
               ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);
    } catch (Throwable t) {
      throw printException(t);
    }

    return retval;

  } //CreateDefectWorkOrder

  /**
   *
   * @webmethod
   */
  public Element InstructWorkOrder(Element workOrder)
  throws Exception
  {
    //Define the return Element
    Element retval = null;
    
    try
    {
      //Convert the workOrder Element to a String and remove
      //the <?xml version="1.0" encoding="UTF-8"?>
      String input = ElementToString(workOrder).substring(43);

      //Prepare The Database Call.
      String sql = "DECLARE"
                 + "  retval xmltype;"
                 + "BEGIN"
                 + "  retval := mai_web_service.instruct_work_order(XMLTYPE('" + input + "'));"
                 + "  ? := retval.getClobVal();"
                 +"END;"
               ;

      //Execute the Database Call.
      retval = executeClobOutStatement(sql);
    } catch (Throwable t) {
      throw printException(t);
    }

    return retval;

  } //InstructWorkOrder

//
//Private Methods.
//

  private Element buildError(String wrapperElement
                            ,String errorMessage)
  throws SAXException, IOException, ParserConfigurationException
  {
    //Define the return Element.
    Element retval = null;

    //Create the Element as a String.
    String error = "<"+wrapperElement+" xmlns=\"http://exor_mai_ws/exor_mai_ws\">"
                    +"<error>"+errorMessage+"</error>"
                  +"</"+wrapperElement+">";

    //Create and return the Element.
    retval = createXMLDocument(new ByteArrayInputStream(error.getBytes())).getDocumentElement();
    return retval;
  }

  private void openConnection()
  throws SQLException, NamingException
  {
    //Get the details of the Data Source with the
    //JNDI Location "jdbc/exorCoreDS" that has been
    //setup in the OC4J containers home page.
    InitialContext context = new InitialContext();
    DataSource ds = (DataSource) context.lookup("jdbc/exorCoreDS");

    //Open the Database Connection.
    this.con = ds.getConnection();
  }

  private void closeConnection()
  {
    try {
      //Close the Database Connection.
      con.close();
    } catch (SQLException e){
      //If a problem occurs print the details
      //to STDOUT and continue processing.
      e.printStackTrace();
    }
  }

  private Element executeClobOutStatement(String statement)
  throws SQLException, NamingException, SAXException, IOException, ParserConfigurationException
  {
    //Define the return Element.
    Element retval = null;

    //Create the statement object.
    CallableStatement stmt = null;

    //Open a database connection.
    openConnection();

    //Execute the statement and get the output as an Element.
    stmt = con.prepareCall(statement);
    stmt.registerOutParameter(1, Types.CLOB);
    stmt.execute();
    Clob clobOut = stmt.getClob(1);
    stmt.close();
    retval = createXMLDocument(clobOut.getAsciiStream()).getDocumentElement();

    //Close the database connection.
    closeConnection();

    //Return the XML Element.
    return retval;
  }

  private String ElementToString(Element input)
    throws TransformerConfigurationException, TransformerException
  {
    //Define the return String.
    String retval = null;

    //Transform the Element to a String.
    if (input!=null)
    {
      Transformer trans = TransformerFactory.newInstance().newTransformer();
      DOMSource doms = new DOMSource(input);
      ByteArrayOutputStream buf = new ByteArrayOutputStream();
      StreamResult streamr = new StreamResult(buf);
      trans.transform(doms, streamr);
      retval = buf.toString();
    }

    //Return the String.
    return retval;
  }

  private Document createXMLDocument(InputStream is)
    throws SAXException, IOException, ParserConfigurationException
  {
    //Define the return Document.
    Document retval = null;

    //Create a document Builder Object.
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    factory.setNamespaceAware(true);
    DocumentBuilder builder = null;
    builder = factory.newDocumentBuilder();

    //Create the XML Document.
    retval = builder.parse(is);

    //Close the InputStream.
    is.close();

    //Return the XML Document.
    return retval;
  }

  private Exception printException(Throwable t) 
  {
    //Create a generic Exception to throw.
    Exception e =  new Exception(t.toString());

    //Print the Details of the Exception to STDOUT.
    t.printStackTrace();

    //Return the Exception.
    return e;
  }

}