package exor_mai_ws;

public interface IExor_mai_ws 
{
  public org.w3c.dom.Element GetAdminUnits(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetAdminGroups(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetUsers(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetRoadSections(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetAssetTypes(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetAssetTypeAttribs(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetAssetIDs(org.w3c.dom.Element input) throws Exception;

  public org.w3c.dom.Element GetModifiedAssetIDs(org.w3c.dom.Element input) throws Exception;

  public org.w3c.dom.Element GetAssetDetails(org.w3c.dom.Element input) throws Exception;

  public org.w3c.dom.Element GetSDFlags(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetInitiationTypes(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetNWActivities(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetAssetActivities(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetDefectTypes(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetSISSCodes(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetPriorities(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetNotifyOrgs(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetRechargeOrgs(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetRepairTypes(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetTreatments(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetStandardItems(org.w3c.dom.Element dummy) throws Exception;
  
  public org.w3c.dom.Element GetStandardPercentItems(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetContracts(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetContractItems(org.w3c.dom.Element input) throws Exception;

  public org.w3c.dom.Element GetSchemeTypes(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetCurrentBudgets(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetRoadGroupSectionIDs(org.w3c.dom.Element input) throws Exception;

  public org.w3c.dom.Element GetWorkOrderPriorities(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetCostCentres(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetDefaultRoadGroups(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element CreateAdhocDefect(org.w3c.dom.Element defect) throws Exception;
  
  public org.w3c.dom.Element GetAvailableDefects(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element CreateDefectWorkOrder(org.w3c.dom.Element defectWorkOrder) throws Exception;

  public org.w3c.dom.Element GetInstructableWorkOrders(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element InstructWorkOrder(org.w3c.dom.Element workOrder) throws Exception;

  public org.w3c.dom.Element GetInstructedWorkOrders(org.w3c.dom.Element dummy) throws Exception;

  public org.w3c.dom.Element GetWorkOrderDetails(org.w3c.dom.Element workOrder) throws Exception;

  public org.w3c.dom.Element SetWorkOrderReceived(org.w3c.dom.Element workOrder) throws Exception;

  public org.w3c.dom.Element SetWorkOrderLineHeld(org.w3c.dom.Element workOrderLine) throws Exception;

  public org.w3c.dom.Element SetWorkOrderLineNotDone(org.w3c.dom.Element workOrderLine) throws Exception;

  public org.w3c.dom.Element CreateInterimPayment(org.w3c.dom.Element workOrderLine) throws Exception;

  public org.w3c.dom.Element CompleteWorkOrderLine(org.w3c.dom.Element workOrderLine) throws Exception;

  public org.w3c.dom.Element CompleteWorkOrder(org.w3c.dom.Element workOrder) throws Exception;

}