package exor_mai_ws;

import java.sql.SQLException;
import sqlj.runtime.ref.DefaultContext;
import sqlj.runtime.ConnectionContext;
import java.sql.Connection;
// Ensure that the java.io.* package etc. is imported.
import java.io.*;

public interface Exor_mai_ws {


  public org.w3c.dom.Element get_road_sections() throws SQLException;
  public org.w3c.dom.Element get_siss_codes() throws SQLException;
  public org.w3c.dom.Element get_treatments() throws SQLException;
  public org.w3c.dom.Element get_initiation_types() throws SQLException;
  public org.w3c.dom.Element get_asset_ids(String piAssetType) throws SQLException;
  public org.w3c.dom.Element get_asset_type_attribs() throws SQLException;
  public org.w3c.dom.Element get_admin_units() throws SQLException;
  public org.w3c.dom.Element get_asset_activities() throws SQLException;
  public org.w3c.dom.Element get_defect_codes() throws SQLException;
  public org.w3c.dom.Element get_priorities() throws SQLException;
  public org.w3c.dom.Element get_standard_items() throws SQLException;
  public org.w3c.dom.Element get_nw_activities() throws SQLException;
  public org.w3c.dom.Element get_repair_types() throws SQLException;
  public org.w3c.dom.Element get_recharge_orgs() throws SQLException;
  public org.w3c.dom.Element get_notify_orgs() throws SQLException;
  public org.w3c.dom.Element get_asset_details(java.math.BigDecimal piAssetId) throws SQLException;
  public org.w3c.dom.Element get_modified_asset_ids(String piAssetType, String piModifiedDate) throws SQLException;
  public org.w3c.dom.Element get_asset_types() throws SQLException;
  public org.w3c.dom.Element get_users() throws SQLException;
  public org.w3c.dom.Element create_adhoc_defect(org.w3c.dom.Element piXml) throws SQLException;
  public org.w3c.dom.Element get_sd_flags() throws SQLException;
  public org.w3c.dom.Element get_admin_groups() throws SQLException;
}
