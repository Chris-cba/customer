/*@lineinfo:filename=Exor_mai_wsBase*//*@lineinfo:user-code*//*@lineinfo:1^1*/package exor_mai_ws;

import java.sql.SQLException;
import sqlj.runtime.ref.DefaultContext;
import sqlj.runtime.ConnectionContext;
import java.sql.Connection;
// Ensure that the java.io.* package etc. is imported.
import java.io.*;

public class Exor_mai_wsBase
{

  /* connection management */
  protected DefaultContext __tx = null;
  protected Connection __onn = null;
  public void _setConnectionContext(DefaultContext ctx) throws SQLException
  { release(); __tx = ctx; 
    ctx.setStmtCacheSize(0);
       ctx.setDefaultStmtCacheSize(0);
       if (ctx.getConnection() instanceof oracle.jdbc.OracleConnection)
       {
          try 
          {
             java.lang.reflect.Method m = ctx.getConnection().getClass().getMethod("setExplicitCachingEnabled", new Class[]{Boolean.TYPE});
             m.invoke(ctx.getConnection(), new Object[]{Boolean.FALSE});
          }
          catch(Exception e) { /* do nothing for pre-9.2 JDBC drivers*/ }
       }}
  public DefaultContext _getConnectionContext() throws SQLException
  { if (__tx==null)
    { __tx = (__onn==null) ? DefaultContext.getDefaultContext() : new DefaultContext(__onn); }
    return __tx;
  };
  public Connection _getConnection() throws SQLException
  { return (__onn==null) ? ((__tx==null) ? null : __tx.getConnection()) : __onn; }
  public void release() throws SQLException
  { if (__tx!=null && __onn!=null) __tx.close(ConnectionContext.KEEP_CONNECTION);
    __onn = null; __tx = null;
  }


  /* constructors */
  public Exor_mai_wsBase() throws SQLException
  { __tx = DefaultContext.getDefaultContext();
 }
  public Exor_mai_wsBase(DefaultContext c) throws SQLException
  { __tx = c; }
  public Exor_mai_wsBase(Connection c) throws SQLException
  {__onn = c; __tx = new DefaultContext(c);  }

  public oracle.sql.SimpleXMLType _get_road_sections ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:55^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ROAD_SECTIONS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ROAD_SECTIONS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"0exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:55^97*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_siss_codes ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:63^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_SISS_CODES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_SISS_CODES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"1exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:63^94*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_treatments ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:71^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_TREATMENTS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_TREATMENTS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"2exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:71^94*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_initiation_types ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:79^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_INITIATION_TYPES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_INITIATION_TYPES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"3exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:79^100*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_asset_ids (
    String piAssetType)
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:88^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ASSET_IDS(
//        :piAssetType))  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ASSET_IDS(\n       :2 )  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"4exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
   // set IN parameters
   __sJT_st.setString(2,piAssetType);
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:89^22*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_asset_type_attribs ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:97^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ASSET_TYPE_ATTRIBS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ASSET_TYPE_ATTRIBS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"5exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:97^102*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_admin_units ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:105^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ADMIN_UNITS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ADMIN_UNITS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"6exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:105^95*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_asset_activities ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:113^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ASSET_ACTIVITIES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ASSET_ACTIVITIES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"7exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:113^100*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_defect_codes ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:121^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_DEFECT_CODES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_DEFECT_CODES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"8exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:121^96*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_priorities ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:129^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_PRIORITIES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_PRIORITIES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"9exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:129^94*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_standard_items ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:137^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_STANDARD_ITEMS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_STANDARD_ITEMS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"10exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:137^98*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_nw_activities ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:145^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_NW_ACTIVITIES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_NW_ACTIVITIES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"11exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:145^97*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_repair_types ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:153^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_REPAIR_TYPES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_REPAIR_TYPES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"12exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:153^96*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_recharge_orgs ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:161^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_RECHARGE_ORGS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_RECHARGE_ORGS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"13exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:161^97*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_notify_orgs ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:169^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_NOTIFY_ORGS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_NOTIFY_ORGS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"14exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:169^95*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_asset_details (
    java.math.BigDecimal piAssetId)
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:178^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ASSET_DETAILS(
//        :piAssetId))  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ASSET_DETAILS(\n       :2 )  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"15exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
   // set IN parameters
   __sJT_st.setBigDecimal(2,piAssetId);
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:179^20*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_modified_asset_ids (
    String piAssetType,
    String piModifiedDate)
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:189^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_MODIFIED_ASSET_IDS(
//        :piAssetType,
//        :piModifiedDate))  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_MODIFIED_ASSET_IDS(\n       :2 ,\n       :3 )  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"16exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
   // set IN parameters
   __sJT_st.setString(2,piAssetType);
   __sJT_st.setString(3,piModifiedDate);
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:191^25*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_asset_types ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:199^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ASSET_TYPES())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ASSET_TYPES()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"17exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:199^95*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_users ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:207^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_USERS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_USERS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"18exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:207^89*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _create_adhoc_defect (
    oracle.sql.SimpleXMLType piXml)
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:216^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.CREATE_ADHOC_DEFECT(
//        :piXml))  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.CREATE_ADHOC_DEFECT(\n       :2 )  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"19exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
   // set IN parameters
   if (piXml==null) __sJT_st.setNull(2,2007,"SYS.XMLTYPE"); else __sJT_st.setORAData(2,piXml);
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:217^16*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_sd_flags ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:225^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_SD_FLAGS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_SD_FLAGS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"20exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:225^92*/
    return __jPt_result;
  }

  public oracle.sql.SimpleXMLType _get_admin_groups ()
  throws SQLException
  {
    oracle.sql.SimpleXMLType __jPt_result;
    /*@lineinfo:generated-code*//*@lineinfo:233^5*/

//  ************************************************************
//  #sql [_getConnectionContext()] __jPt_result = { VALUES(MAI_WEB_SERVICE.GET_ADMIN_GROUPS())  };
//  ************************************************************

{
  // declare temps
  oracle.jdbc.OracleCallableStatement __sJT_st = null;
  sqlj.runtime.ref.DefaultContext __sJT_cc = _getConnectionContext(); if (__sJT_cc==null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext.OracleContext __sJT_ec = ((__sJT_cc.getExecutionContext()==null) ? sqlj.runtime.ExecutionContext.raiseNullExecCtx() : __sJT_cc.getExecutionContext().getOracleContext());
  try {
   String theSqlTS = "BEGIN :1 := MAI_WEB_SERVICE.GET_ADMIN_GROUPS()  \n; END;";
   __sJT_st = __sJT_ec.prepareOracleCall(__sJT_cc,"21exor_mai_ws.Exor_mai_wsBase",theSqlTS);
   if (__sJT_ec.isNew())
   {
      __sJT_st.registerOutParameter(1,2007,"SYS.XMLTYPE");
   }
 // execute statement
   __sJT_ec.oracleExecuteUpdate();
   // retrieve OUT parameters
   __jPt_result = (oracle.sql.SimpleXMLType)__sJT_st.getORAData(1,oracle.sql.SimpleXMLType.getORADataFactory());
  } finally { __sJT_ec.oracleClose(); }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:233^96*/
    return __jPt_result;
  }
}/*@lineinfo:generated-code*/