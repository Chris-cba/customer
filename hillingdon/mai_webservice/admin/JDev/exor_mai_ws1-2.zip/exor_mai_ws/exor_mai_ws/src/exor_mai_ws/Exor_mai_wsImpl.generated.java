/*@lineinfo:filename=Exor_mai_wsImpl*//*@lineinfo:user-code*//*@lineinfo:1^1*/package exor_mai_ws;

import java.sql.SQLException;
import sqlj.runtime.ref.DefaultContext;
import sqlj.runtime.ConnectionContext;
import java.sql.Connection;
// Ensure that the java.io.* package etc. is imported.
import java.io.*;

public class Exor_mai_wsImpl extends Exor_mai_wsBase implements Exor_mai_ws
{

  /* constructors */
  public Exor_mai_wsImpl() throws SQLException  { super(); }
  public Exor_mai_wsImpl(DefaultContext c) throws SQLException { super(c); }
  public Exor_mai_wsImpl(Connection c) throws SQLException { super(c); }
  /* superclass methods */
  public org.w3c.dom.Element get_road_sections() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_road_sections();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_siss_codes() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_siss_codes();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_treatments() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_treatments();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_initiation_types() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_initiation_types();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_asset_ids(String piAssetType) throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_asset_ids(piAssetType);

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_asset_type_attribs() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_asset_type_attribs();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_admin_units() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_admin_units();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_asset_activities() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_asset_activities();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_defect_codes() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_defect_codes();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_priorities() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_priorities();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_standard_items() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_standard_items();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_nw_activities() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_nw_activities();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_repair_types() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_repair_types();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_recharge_orgs() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_recharge_orgs();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_notify_orgs() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_notify_orgs();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_asset_details(java.math.BigDecimal piAssetId) throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_asset_details(piAssetId);

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_modified_asset_ids(String piAssetType, String piModifiedDate) throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_modified_asset_ids(piAssetType, piModifiedDate);

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_asset_types() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_asset_types();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_users() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_users();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element create_adhoc_defect(org.w3c.dom.Element piXml) throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    oracle.sql.SimpleXMLType xpiXmlx;
    try 
    {
      javax.xml.transform.Transformer trans = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
      xpiXmlx = null;
      if (piXml!=null)
      {
        javax.xml.transform.dom.DOMSource doms = new javax.xml.transform.dom.DOMSource(piXml);
        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
        javax.xml.transform.stream.StreamResult streamr = new javax.xml.transform.stream.StreamResult(buf);
        trans.transform(doms, streamr);
        xpiXmlx = new oracle.sql.SimpleXMLType(_getConnection());
        String bufText = buf.toString();
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.createxml(" + bufText + ")");
        xpiXmlx = xpiXmlx.createxml(bufText); 
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    __jRt_0 = super._create_adhoc_defect(xpiXmlx);

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_sd_flags() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_sd_flags();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
  public org.w3c.dom.Element get_admin_groups() throws SQLException
  { 
    oracle.sql.SimpleXMLType __jRt_0 = null;

    org.w3c.dom.Element __jRt_1 = null;
    __jRt_0 = super._get_admin_groups();

    try 
    {
      javax.xml.parsers.DocumentBuilder db = 
      javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder();
      __jRt_1 = null;
      if (__jRt_0!=null) 
      {
        if (OC4JWsDebug()) System.out.println("WS Debug: SimpleXMLType.getstringval() returns <" + __jRt_0.getstringval() + ">");
        /* - JDeveloper generated code cannot deal with large XML values.
        org.w3c.dom.Document doc =db.parse(new java.io.ByteArrayInputStream(__jRt_0.getstringval().getBytes()));
        */
        String strxml;
        strxml = readerToString(__jRt_0.getclobval().characterStreamValue());
        java.io.ByteArrayInputStream inputxml;
        inputxml = new java.io.ByteArrayInputStream(strxml.getBytes());
        org.w3c.dom.Document doc = db.parse(inputxml);
        /* End Of Non-Generated Code */
        __jRt_1 = doc.getDocumentElement();
      }
    }
    catch (java.lang.Throwable t)
    {
      throw OC4JWsDebugPrint(t);
    }
    return __jRt_1;
  }
 private java.lang.String readerToString(java.io.Reader r)
     throws java.sql.SQLException
{
 	
        CharArrayWriter caw = new CharArrayWriter();
        
        try
          {
        	//Read from reader and write to writer
        	boolean done = false;
        
        	while (!done)
        	{
            		char[] buf = new char[4096];

            		int len = r.read(buf, 0, 4096);
            
            		if(len == -1)
            		{
                	done = true;
            		}
            		else
            		{
                		caw.write(buf,0,len);
            		}
                }
           }
         catch(Throwable t)
         {
           throw OC4JWsDebugPrint(t);
         }  
        return caw.toString();
}
//    private void populateClob(oracle.sql.CLOB clb, java.lang.String data) 
//            throws Exception
//    {
//     	java.io.Writer writer = clb.getCharacterOutputStream();
//     	writer.write(data.toCharArray());
//     	writer.flush();	 
//    	writer.close();       
//   }
    private boolean OC4JWsDebug() 
    {
      boolean debug = false;
      try {
        // Server-side Debug Info for "java -Dws.debug=true -jar oc4j.jar" 
	Class sutil = Class.forName("com.evermind.util.SystemUtils");
	java.lang.reflect.Method getProp = sutil.getMethod("getSystemBoolean", new Class[]{String.class, Boolean.TYPE});
	if (((Boolean)getProp.invoke(null, new Object[]{"ws.debug", Boolean.FALSE})).booleanValue()) 
	{
	  debug = true;
	}
      }  catch (Throwable except2) {}
      return debug;
    }
    private java.sql.SQLException OC4JWsDebugPrint(Throwable t) 
    {
      java.sql.SQLException t0 =  new java.sql.SQLException(t.getMessage());
      if (!OC4JWsDebug()) return t0;
      t.printStackTrace();
      try 
      {
        java.lang.reflect.Method getST = Exception.class.getMethod("getStackTrace", new Class[]{});
        java.lang.reflect.Method setST = Exception.class.getMethod("setStackTrace", new Class[]{});
        setST.invoke(t0, new Object[]{getST.invoke(t, new Object[]{})});
      }
      catch (Throwable th){}
      return t0;
    }
}/*@lineinfo:generated-code*/