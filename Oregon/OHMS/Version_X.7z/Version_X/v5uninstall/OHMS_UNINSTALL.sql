

delete from HIG_STANDARD_FAVOURITES where HSTF_PARENT = 'OHMS';

delete from HIG_STANDARD_FAVOURITES where HSTF_CHILD = 'OHMS';

delete from GRI_MODULES where GRM_MODULE = 'OHMS_RUN';


delete from HIG_MODULES where 
 HMO_APPLICATION = 'OHMS';

declare

l_merge_id NM_MRG_QUERY_ALL.nmq_id%type;

begin


    select nmq_id into l_merge_id from NM_MRG_QUERY_ALL where NMQ_UNIQUE = 'OHMS_EXTRACT';
    
    delete from  NM_MRG_QUERY_ALL where NMQ_ID = l_merge_id;
    
    exception
    when others then null;
    
end;
/


DROP TABLE V_NM_OHMS_NW CASCADE CONSTRAINTS;
DROP TABLE OHMS_SUBMIT_SAMPLES;
DROP TABLE OHMS_ACTIVITY_LOG;


@zDrop_HPMS_TV.sql


drop Procedure XODOT_POPULATE_OHMS_SECTIONS;  --just using the item straight form HPMS
drop procedure XNA_HPMS_POPULATE_7;
drop package xodot_OHMS;


