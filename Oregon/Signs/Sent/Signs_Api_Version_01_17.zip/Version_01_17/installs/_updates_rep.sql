
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_signs_logging_tables_seq.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_signs_logging_tables_seq.sql
SET FEEDBACK OFF


--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\report_lookup_tables.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\report_lookup_tables.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_rollup_mp.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_rollup_mp.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_rollup_mp.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_rollup_mp.pkb
SET FEEDBACK OFF