--
SET TERM ON
PROMPT *** RUNNING:drop type xodot_signs_task_list; ***
SET TERM OFF
--
SET FEEDBACK ON
drop type xodot_signs_task_list;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop type xodot_signs_task_list_row; ***
SET TERM OFF
--
SET FEEDBACK ON
drop type xodot_signs_task_list_row;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop type xodot_signs_asset_op; ***
SET TERM OFF
--
SET FEEDBACK ON
drop type xodot_signs_asset_op;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop index xsigns_date_chk_idx; ***
SET TERM OFF
--
SET FEEDBACK ON
drop index xsigns_date_chk_idx;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop trigger xodot_signs_asset_domain_trg; ***
SET TERM OFF
--
SET FEEDBACK ON
drop trigger xodot_signs_asset_domain_trg;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop package body xodot_signs_api; ***
SET TERM OFF
--
SET FEEDBACK ON
drop package body xodot_signs_api;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop package  xodot_signs_api; ***
SET TERM OFF
--
SET FEEDBACK ON
drop package  xodot_signs_api;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop package body xodot_signs_logging; ***
SET TERM OFF
--
SET FEEDBACK ON
drop package body xodot_signs_logging;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING:drop package xodot_signs_logging; ***
SET TERM OFF
--
SET FEEDBACK ON
drop package xodot_signs_logging;
SET FEEDBACK OFF

