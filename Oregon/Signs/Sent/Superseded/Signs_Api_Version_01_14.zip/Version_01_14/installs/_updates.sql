--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\api_custom_types.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\api_custom_types.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_signs_logging_tables_seq.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_signs_logging_tables_seq.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_signs_logging.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_signs_logging.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_signs_logging.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_signs_logging.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_signs_api.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_signs_api.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xodot_signs_api.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xodot_signs_api.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\triggers\xodot_signs_asset_domain_trg.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\triggers\xodot_signs_asset_domain_trg.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\other\sign_api_indexes.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\other\sign_api_indexes.sql
SET FEEDBACK OFF
--
--
