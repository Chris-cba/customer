--
SET TERM ON
PROMPT *** RUNNING: drop package body reports.xodot_rollup_mp; ***
SET TERM OFF
--
SET FEEDBACK ON
drop package body reports.xodot_rollup_mp;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: drop package reports.xodot_rollup_mp; ***
SET TERM OFF
--
SET FEEDBACK ON
drop package reports.xodot_rollup_mp;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: drop table REPORTS.X_SIGNS_TBLHWYLKUP_IN; ***
SET TERM OFF
--
SET FEEDBACK ON
drop table REPORTS.X_SIGNS_TBLHWYLKUP_IN;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: drop table REPORTS.X_SIGNS_TBLHWYLKUP_OUT; ***
SET TERM OFF
--
SET FEEDBACK ON
drop table REPORTS.X_SIGNS_TBLHWYLKUP_OUT;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: drop table reports.xsign_except; ***
SET TERM OFF
--
SET FEEDBACK ON
drop table reports.xsign_except;
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: drop table REPORTS.XSIGN_STATUS; ***
SET TERM OFF
--
SET FEEDBACK ON
drop table REPORTS.XSIGN_STATUS;
SET FEEDBACK OFF
--
--
