--
-----------------------------------------------------------------------------
--
--   PVCS Identifiers :-
--
--       pvcsid                 : $Header:   //vm_latest/archives/customer/Oregon/FI Reporting/admin/Project1/remove_fi_reporting.sql-arc   3.0   Sep 06 2010 11:15:32   Ian.Turnbull  $
--       Module Name      : $Workfile:   remove_fi_reporting.sql  $
--       Date into PVCS   : $Date:   Sep 06 2010 11:15:32  $
--       Date fetched Out : $Modtime:   Aug 31 2010 16:48:24  $
--       PVCS Version     : $Revision:   3.0  $
--
--
--   Author : P Stanton
--
-----------------------------------------------------------------------------
--	Copyright (c) exor corporation ltd, 2010
-----------------------------------------------------------------------------
--
-- Sctipt to remove Bike Ped
drop table XODOT_HBUD_FI_REPORT;

drop package XODOT_FI_REPORT;



