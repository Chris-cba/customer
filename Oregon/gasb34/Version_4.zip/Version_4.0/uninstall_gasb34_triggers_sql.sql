-- script to install GASB34 triggers.

drop  package TRANSINFO.xodot_elements_state;


drop  TRIGGER TRANSINFO.xodot_ins_b_elements;

drop TRIGGER xodot_upd_trnf_grp_mem_attribs;


drop TRIGGER TRANSINFO.xodot_upd_a_elements_trans;

