--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_lohac_daterange_wowt.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_lohac_daterange_wowt.sql
SET FEEDBACK OFF
--
--
set term on
prompt *** running: ..\admin\sql\x_lohac_daterange_wodc.sql ***
set term off
--
set feedback on
start ..\admin\sql\x_lohac_daterange_wodc.sql
set feedback off
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_lohac_daterange_wowt003.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_lohac_daterange_wowt003.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\x_lohac_nobudget_security.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\x_lohac_nobudget_security.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\ximf_mai_wo_all_attr_no_sec.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\ximf_mai_wo_all_attr_no_sec.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\xtfl_wo_sec_u_trg.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\xtfl_wo_sec_u_trg.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\46_3.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\46_3.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\47_5.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\47_5.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\date_range.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\date_range.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\wowt003-x_wo_tfl_work_tray_im511003_full.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\wowt003-x_wo_tfl_work_tray_im511003_full.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41021-work_due_to_be_cmp_no_df_child.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41021-work_due_to_be_cmp_no_df_child.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41040-c_pod_eop_updated.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41040-c_pod_eop_updated.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41040-c_pod_eop_updated_dd_nobud.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41040-c_pod_eop_updated_dd_nobud.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im_pods.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im_pods.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im_pod_sql.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im_pod_sql.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im_pod_sql_2.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im_pod_sql_2.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im_pod_chart.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im_pod_chart.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\wowt001-x_wo_tfl_work_tray_im511001.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\wowt001-x_wo_tfl_work_tray_im511001.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\wowt001-x_wo_tfl_work_tray_im511001_nobud.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\wowt001-x_wo_tfl_work_tray_im511001_nobud.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\wowt003-x_wo_tfl_work_tray_im511003_all.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\wowt003-x_wo_tfl_work_tray_im511003_all.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\wowt003-x_wo_tfl_work_tray_im511003_all_nobud.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\wowt003-x_wo_tfl_work_tray_im511003_all_nobud.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\applicationreview.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\applicationreview.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\applicationstatus.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\applicationstatus.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41015-c_pod_eop_requests.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41015-c_pod_eop_requests.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41015-c_pod_eop_requests_nobud.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41015-c_pod_eop_requests_nobud.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41015-c_pod_eot_requests.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41015-c_pod_eot_requests.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41035-rejected_wo_base.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41035-rejected_wo_base.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41035-rejected_wo_base_nobud.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41035-rejected_wo_base_nobud.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41036-held_wo_base.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41036-held_wo_base.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41036-held_wo_base_nobud.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41036-held_wo_base_nobud.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41037a-dd1-base.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41037a-dd1-base.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41037-dd1-base.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41037-dd1-base.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41038a-dd1-base.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41038a-dd1-base.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41038-dd1-base.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41038-dd1-base.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\im41040-c_pod_eop_updated_dd.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\im41040-c_pod_eop_updated_dd.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\index.ind ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\index.ind
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\f512.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\f512.sql
SET FEEDBACK OFF
