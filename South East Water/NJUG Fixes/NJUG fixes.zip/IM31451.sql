REM INSERTING into IM_POD_SQL
SET DEFINE OFF;
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1018,1179,10,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 1
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','01-An offence under s55(4)','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1019,1179,60,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 6
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','06-An offence created by regulations under s74A(7B)','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1106,1179,80,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 8
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','PS01-Working without a permit','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1107,1179,90,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 9
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','PS02-Working in breach of permit conditions','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1143,1179,40,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 4
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','04-An offence under s57(4)','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1144,1179,20,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 2
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','02-An offence under s55(5)','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1145,1179,50,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 5
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','05-An offence under s70(6), fail subsection (3) or (4A)','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1191,1179,30,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 3
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','03-An offence under s55(9)','Bar','Cylinder',null);
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1192,1179,70,'Select ''javascript:doDrillDown(''''IM31451'''', ''''''||To_Char(s_date, ''Mon YYYY'')||'''''', ''''''||fpn_offence_code||'''''');'' link , To_Char(s_date, ''Mon YYYY'') MMM, nvl(cnt,0)  from (
Select  f.fpn_offence_code , To_Char(f.payment_recvd_date,''Mon YYYY''), Count (f.fpn_id) as cnt, sorter S
From    IMF_TMA_FPNS f, xim_3months 
Where   f.payment_recvd_date Between S_date and E_Date
--Last 3/4 months
And f.fpn_offence_code = 7
GROUP BY sorter,To_Char (f.payment_recvd_date, ''Mon YYYY''), f.fpn_offence_code
) a, xim_3months  dr where dr.sorter = a.s(+) order by s','07-An offence created by regulations under s74A(11)','Bar','Cylinder',null);
