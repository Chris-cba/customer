REM INSERTING into IM_POD_SQL
SET DEFINE OFF;
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1245,1259,1,'Select  PROMOTER_ORG_NAME as "Organisation Name"
, PROMOTER_ORG_REF as "Organisation Ref"
, ''<a  href="javascript:doDrillDown(''''IM31862'''',''''''||:P6_PARAM1||'''''',''''''||:P6_PARAM2||'''''',''''''||PROMOTER_ORG_REF ||'''''',''''''||PROMOTER_DIST_REF||'''''');">''||PROMOTER_DIST_NAME||''</a>'' as "District Name"
, PROMOTER_DIST_REF as "District Ref"
        ,Sum (p.calculated_fee) as "Cost"
From  IMF_TMA_PHASES w
      ,IMF_TMA_PERMIT_FEES p
Where w.works_id = p.works_id
And w.phase_number = p.phase_number
And w.works_category = to_number(trim(:P6_PARAM2))
and To_Char (p.fee_date,''Mon YYYY'') = :P6_PARAM1
GROUP BY PROMOTER_ORG_NAME,PROMOTER_ORG_REF,PROMOTER_DIST_NAME,PROMOTER_DIST_REF
Order By PROMOTER_ORG_REF,PROMOTER_DIST_REF
','series125','Bar','Box',null);
