create or replace view xIM_3MONTHS as (
select 0 sorter, trunc(trunc(add_months(sysdate,-2),'MM')-1,'MM') S_Date, trunc(add_months(sysdate,-2),'MM')-1 E_Date from dual
union
select 1 sorter, trunc(trunc(add_months(sysdate,-1),'MM')-1,'MM') S_Date, trunc(add_months(sysdate,-1),'MM')-1 E_Date from dual
union
select 2 sorter, trunc(trunc(add_months(sysdate,-0),'MM')-1,'MM') S_Date, trunc(add_months(sysdate,-0),'MM')-1 E_Date from dual
union
select 3 sorter, trunc(trunc(sysdate),'MM') S_Date, trunc(add_months(trunc(sysdate,'MM'),1),'MM')-1 E_Date from dual
);