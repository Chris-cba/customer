REM INSERTING into IM_POD_SQL
SET DEFINE OFF;
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1243,1257,1,'Select  w.organisation_name as "Organisation Name"
, w.organisation_reference as "Organisation Ref"
, ''<a  href="javascript:doDrillDown(''''IM31842'''',''''''||:P6_PARAM1||'''''',''''''||w.ORGANISATION_REFERENCE ||'''''',''''''||w.DISTRICT_REFERENCE||'''''');">''||w.DISTRICT_NAME ||''</a>'' as "District Name"
, w.district_reference as "District Ref"
          ,Count (n.works_id) as "Unchallenged"
From    IMF_TMA_NOTICES n
        ,IMF_TMA_PHASES p, IMF_TMA_NOTICE_RECIPIENTS r,IMF_TMA_WORKS w
        ,(Select   n2.works_id
                  ,n2.phase_number
                  ,max (n2.notice_sequence_number) seq
          From    IMF_TMA_NOTICES n2
          Where   n2.notice_type In (''0400'',''1000'')
          GROUP BY n2.works_id
                  ,n2.phase_number
          ) s
Where To_Char (n.actual_start_date, ''Mon YYYY'') = :P6_PARAM1
And   n.notice_type = 400
And   n.works_id = s.works_id
And   n.phase_number = s.phase_number
And   n.notice_sequence_number = s.seq
And   n.works_id = p.works_id
and   n.works_id = w.works_id
And   n.phase_number = p.phase_number
And   p.notice_regime = ''PERMIT''
And   Not Exists
        (Select 1
        From  IMF_TMA_NOTICES n3
        Where n3.notice_type = ''1613''
        And   n.works_id = n3.works_id
        And   n.phase_number = n3.phase_number)
And n.notice_id = r.notice_id
and r.recipient_type = 1
GROUP BY  w.organisation_name, w.organisation_reference, w.district_name, w.district_reference
Order By w.organisation_reference, w.district_reference','series124','Bar','Box',null);
