REM INSERTING into IM_POD_SQL
SET DEFINE OFF;
Insert into IM_POD_SQL (IPS_ID,IPS_IP_ID,IPS_SEQ,IPS_SOURCE_CODE,IPS_NAME,IPS_TYPE,IPS_SHAPE_TYPE,IPS_NE_ID_COLUMN) values (1238,1252,1,'Select  UNDERTAKER_ORG_REFERENCE_NAME as "Undertaker Org Reference Name"
 , UNDERTAKER_ORG_REFERENCE as "Undertaker Org Reference"
 ,  ''<a  href="javascript:doDrillDown(''''IM31682'''',''''''||:P6_PARAM1||'''''',''''''||UNDERTAKER_ORG_REFERENCE ||'''''',''''''||UNDERTAKER_DISTRICT_REF||'''''');">''||UNDERTAKER_DISTRICT_REF_NAME ||''</a>''  as "Undertaker District Ref Name"
, ''<a  href="javascript:doDrillDown(''''IM31682'''',''''''||:P6_PARAM1||'''''',''''''||UNDERTAKER_ORG_REFERENCE ||'''''',''''''||UNDERTAKER_DISTRICT_REF||'''''');">''||UNDERTAKER_DISTRICT_REF ||''</a>'' as "Undertaker District Ref"
        ,Count (i.inspection_id) as "Re-inspections"
From    IMF_TMA_INSPECTION_RESULTS i
        ,(Select  i2.works_id
                  ,i2.inspection_date
                  ,i2.result_number+1 result_no
          From    IMF_TMA_INSPECTION_RESULTS i2
          Where   i2.inspection_date Between To_Date (TO_CHAR(''01-'')||TO_CHAR (SYSDATE, ''MON'')||''-''|| To_Char(To_Number(To_Char (To_Date(Sysdate),''YYYY''))-1), ''DD-MM-YYYY'') And Last_Day (Sysdate)
          And     i2.inspection_type In (1,3,5,7)
          And     i2.outcome_type In (2,3)
          Order By  i2.inspection_id
                    ,result_no) i3
Where   To_Char(i.inspection_date ,''Mon YYYY'') = :P6_PARAM1
And     i.outcome_type In (2,3)
And     i.works_id = i3.works_id
And     i.result_number = i3.result_no
And     Not Exists
        (Select 1
        From  IMF_TMA_PHASES p
        Where p.works_id = i.works_id
        And   p.proposed_start_date Between i.inspection_date And  i3.inspection_date)
GROUP BY UNDERTAKER_ORG_REFERENCE_NAME, UNDERTAKER_ORG_REFERENCE, UNDERTAKER_DISTRICT_REF_NAME, UNDERTAKER_DISTRICT_REF
Order By UNDERTAKER_ORG_REFERENCE,UNDERTAKER_DISTRICT_REF','series47','Bar','Cylinder',null);
