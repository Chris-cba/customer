--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\index\date_modified.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\index\date_modified.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\XBCC_GLOBAL_TEMP.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\XBCC_GLOBAL_TEMP.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\x_log_table.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\x_log_table.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\x_log_table.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\x_log_table.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\XBCC_SAP_SYNC.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\XBCC_SAP_SYNC.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\XBCC_SAP_SYNC.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\XBCC_SAP_SYNC.pkb
SET FEEDBACK OFF
--
--

