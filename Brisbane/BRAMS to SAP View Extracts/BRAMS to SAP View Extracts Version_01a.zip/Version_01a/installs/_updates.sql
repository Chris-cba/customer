--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\procedures\XBCC_CONTEXT_DATES.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\procedures\XBCC_CONTEXT_DATES.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\xbcc_equip_attr_views_tt.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\xbcc_equip_attr_views_tt.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\XBCC_INV_ITEMS_BT.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\XBCC_INV_ITEMS_BT.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\XBCC_MEMBERS_BT.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\XBCC_MEMBERS_BT.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\XBCC_ELEMENTS_BT.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\XBCC_ELEMENTS_BT.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\views\XBCC_EQUIP_ATTR_VIEWS_ESUR.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\views\XBCC_EQUIP_ATTR_VIEWS_ESUR.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xBCC_EquipAttrVeiws.pkb ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xBCC_EquipAttrVeiws.pkb
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\packages\xBCC_EquipAttrVeiws.pkh ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\packages\xBCC_EquipAttrVeiws.pkh
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\xBCC_EAV_input.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\xBCC_EAV_input.sql
SET FEEDBACK OFF
--
--
SET TERM ON
PROMPT *** RUNNING: ..\admin\sql\tables\input_examples.sql ***
SET TERM OFF
--
SET FEEDBACK ON
START ..\admin\sql\tables\input_examples.sql
SET FEEDBACK OFF
--
--
