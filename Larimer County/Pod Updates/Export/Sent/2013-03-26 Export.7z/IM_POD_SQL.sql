SET DEFINE OFF;
MERGE INTO HIGHWAYS.IM_POD_SQL A USING
 (SELECT
  542 as IPS_ID,
  742 as IPS_IP_ID,
  1 as IPS_SEQ,
  'select ne_id
,ne_unique
,ne_descr
,ne_no_start
,ne_no_end
,ne_nt_type 
,ne_type
--
,''<a href="javascript:doDrillDown(''''IM90232'''',''''''  || ne_id || '''''','''''' || null || '''''','''''' || null  || '''''');"><img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''SREPORT'')||''" alt="Report Card"></a>'' "Report Card"  --sample_report.gif
,''<a href="javascript:doDrillDown(''''IM90233'''',''''''  || ne_id || '''''','''''' || null || '''''','''''' || null  || '''''');"><img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''AMBULANCE'')||''" alt="Accident Summary"></a>''  "Accident Summary" -- ambulance-24x24x8b.png
,''<a href="javascript:doDrillDown(''''IM90234'''',''''''  || ne_id || '''''','''''' || null || '''''','''''' || null  || '''''');"><img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''CALC'')||''" alt="Traffic Count"></a>'' "Traffic Count" --calculator_go.png
--
, decode(im_framework.has_doc(ne_id,''ROAD_SEGMENTS_ALL''),0,
''<img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''MFCLOSED'')||''" alt="No Documents">''
,''<a href="javascript:showDocAssocsWT(''||ne_id||'',&APP_ID.,&APP_SESSION.,''''ROAD_SEGMENTS_ALL'''')" ><img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''MFOPEN'')||''" alt="Show Documents"></a>'') DOCS,
decode(road_network_sdo_id,null,
''<img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''GG'')||''" alt="No Location">''
,''<a href="javascript:showPopUpMap(''''''||ne_unique||'''''',&APP_ID.,&APP_SESSION.);" ><img width=24 height=24 src="''||(select imagedir || filename from xim_icons where item = ''G64'')||''" alt="Find on Map"></a>'') map
from nm_elements, road_network_sdo_table
where ne_id = road_network_sdo_id(+)
and ne_type=''S''
and ne_group= :P6_PARAM1' as IPS_SOURCE_CODE,
  '1' as IPS_NAME,
  'Bar' as IPS_TYPE,
  'Box' as IPS_SHAPE_TYPE,
  NULL as IPS_NE_ID_COLUMN
  FROM DUAL) B
ON (A.IPS_ID = B.IPS_ID)
WHEN NOT MATCHED THEN 
INSERT (
  IPS_ID, IPS_IP_ID, IPS_SEQ, IPS_SOURCE_CODE, IPS_NAME, 
  IPS_TYPE, IPS_SHAPE_TYPE, IPS_NE_ID_COLUMN)
VALUES (
  B.IPS_ID, B.IPS_IP_ID, B.IPS_SEQ, B.IPS_SOURCE_CODE, B.IPS_NAME, 
  B.IPS_TYPE, B.IPS_SHAPE_TYPE, B.IPS_NE_ID_COLUMN)
WHEN MATCHED THEN
UPDATE SET 
  A.IPS_IP_ID = B.IPS_IP_ID,
  A.IPS_SEQ = B.IPS_SEQ,
  A.IPS_SOURCE_CODE = B.IPS_SOURCE_CODE,
  A.IPS_NAME = B.IPS_NAME,
  A.IPS_TYPE = B.IPS_TYPE,
  A.IPS_SHAPE_TYPE = B.IPS_SHAPE_TYPE,
  A.IPS_NE_ID_COLUMN = B.IPS_NE_ID_COLUMN;

MERGE INTO HIGHWAYS.IM_POD_SQL A USING
 (SELECT
  561 as IPS_ID,
  761 as IPS_IP_ID,
  1 as IPS_SEQ,
  'select b.ne_group ne_group,
''<a href="javascript:doDrillDown(''''IM90231'''',''''''  ||b.ne_group || '''''','''''' || null || '''''','''''' || null  || '''''');"><font face="verdana" color="blue"><u>''|| a.ne_descr ||''</u></font></a>'' Route
from nm_elements a, (select distinct nm_ne_id_in, ne_group from nm_members, nm_elements where nm_ne_id_of = ne_id and ne_type=''S'') b
where 1=1
and a.ne_id = b.nm_ne_id_in
and a.ne_nt_Type=''CRTE''
and a.ne_type=''G''
order by b.ne_group' as IPS_SOURCE_CODE,
  '1' as IPS_NAME,
  'Bar' as IPS_TYPE,
  'Box' as IPS_SHAPE_TYPE,
  NULL as IPS_NE_ID_COLUMN
  FROM DUAL) B
ON (A.IPS_ID = B.IPS_ID)
WHEN NOT MATCHED THEN 
INSERT (
  IPS_ID, IPS_IP_ID, IPS_SEQ, IPS_SOURCE_CODE, IPS_NAME, 
  IPS_TYPE, IPS_SHAPE_TYPE, IPS_NE_ID_COLUMN)
VALUES (
  B.IPS_ID, B.IPS_IP_ID, B.IPS_SEQ, B.IPS_SOURCE_CODE, B.IPS_NAME, 
  B.IPS_TYPE, B.IPS_SHAPE_TYPE, B.IPS_NE_ID_COLUMN)
WHEN MATCHED THEN
UPDATE SET 
  A.IPS_IP_ID = B.IPS_IP_ID,
  A.IPS_SEQ = B.IPS_SEQ,
  A.IPS_SOURCE_CODE = B.IPS_SOURCE_CODE,
  A.IPS_NAME = B.IPS_NAME,
  A.IPS_TYPE = B.IPS_TYPE,
  A.IPS_SHAPE_TYPE = B.IPS_SHAPE_TYPE,
  A.IPS_NE_ID_COLUMN = B.IPS_NE_ID_COLUMN;

MERGE INTO HIGHWAYS.IM_POD_SQL A USING
 (SELECT
  543 as IPS_ID,
  743 as IPS_IP_ID,
  1 as IPS_SEQ,
  'select * from xlar_im_report_card_Decode1
where ne_id = :P6_PARAM1' as IPS_SOURCE_CODE,
  '1' as IPS_NAME,
  'Bar' as IPS_TYPE,
  'Box' as IPS_SHAPE_TYPE,
  NULL as IPS_NE_ID_COLUMN
  FROM DUAL) B
ON (A.IPS_ID = B.IPS_ID)
WHEN NOT MATCHED THEN 
INSERT (
  IPS_ID, IPS_IP_ID, IPS_SEQ, IPS_SOURCE_CODE, IPS_NAME, 
  IPS_TYPE, IPS_SHAPE_TYPE, IPS_NE_ID_COLUMN)
VALUES (
  B.IPS_ID, B.IPS_IP_ID, B.IPS_SEQ, B.IPS_SOURCE_CODE, B.IPS_NAME, 
  B.IPS_TYPE, B.IPS_SHAPE_TYPE, B.IPS_NE_ID_COLUMN)
WHEN MATCHED THEN
UPDATE SET 
  A.IPS_IP_ID = B.IPS_IP_ID,
  A.IPS_SEQ = B.IPS_SEQ,
  A.IPS_SOURCE_CODE = B.IPS_SOURCE_CODE,
  A.IPS_NAME = B.IPS_NAME,
  A.IPS_TYPE = B.IPS_TYPE,
  A.IPS_SHAPE_TYPE = B.IPS_SHAPE_TYPE,
  A.IPS_NE_ID_COLUMN = B.IPS_NE_ID_COLUMN;

MERGE INTO HIGHWAYS.IM_POD_SQL A USING
 (SELECT
  544 as IPS_ID,
  744 as IPS_IP_ID,
  1 as IPS_SEQ,
  'Select b.aal_meaning,nvl(sev_Count,0) sev_Count from 
(
select aal_meaning,sev_Count
from XLAR_MV_LCRB_ACC_SEV_3_YEAR
,acc_attr_lookup
where aia_value=aal_value
and aal_aad_id=''ASEV''
and alo_ne_id=:P6_PARAM1
) a
, (select * from acc_attr_lookup where aal_aad_id=''ASEV'') b
where a.aal_meaning(+) = b.aal_meaning
order by b.aal_meaning
' as IPS_SOURCE_CODE,
  '1' as IPS_NAME,
  'Bar' as IPS_TYPE,
  'Box' as IPS_SHAPE_TYPE,
  NULL as IPS_NE_ID_COLUMN
  FROM DUAL) B
ON (A.IPS_ID = B.IPS_ID)
WHEN NOT MATCHED THEN 
INSERT (
  IPS_ID, IPS_IP_ID, IPS_SEQ, IPS_SOURCE_CODE, IPS_NAME, 
  IPS_TYPE, IPS_SHAPE_TYPE, IPS_NE_ID_COLUMN)
VALUES (
  B.IPS_ID, B.IPS_IP_ID, B.IPS_SEQ, B.IPS_SOURCE_CODE, B.IPS_NAME, 
  B.IPS_TYPE, B.IPS_SHAPE_TYPE, B.IPS_NE_ID_COLUMN)
WHEN MATCHED THEN
UPDATE SET 
  A.IPS_IP_ID = B.IPS_IP_ID,
  A.IPS_SEQ = B.IPS_SEQ,
  A.IPS_SOURCE_CODE = B.IPS_SOURCE_CODE,
  A.IPS_NAME = B.IPS_NAME,
  A.IPS_TYPE = B.IPS_TYPE,
  A.IPS_SHAPE_TYPE = B.IPS_SHAPE_TYPE,
  A.IPS_NE_ID_COLUMN = B.IPS_NE_ID_COLUMN;

MERGE INTO HIGHWAYS.IM_POD_SQL A USING
 (SELECT
  545 as IPS_ID,
  745 as IPS_IP_ID,
  1 as IPS_SEQ,
  'select count_year,adt_adj 
from xlar_v_adt
where ne_id_of=:P6_PARAM1' as IPS_SOURCE_CODE,
  '1' as IPS_NAME,
  'Bar' as IPS_TYPE,
  'Box' as IPS_SHAPE_TYPE,
  NULL as IPS_NE_ID_COLUMN
  FROM DUAL) B
ON (A.IPS_ID = B.IPS_ID)
WHEN NOT MATCHED THEN 
INSERT (
  IPS_ID, IPS_IP_ID, IPS_SEQ, IPS_SOURCE_CODE, IPS_NAME, 
  IPS_TYPE, IPS_SHAPE_TYPE, IPS_NE_ID_COLUMN)
VALUES (
  B.IPS_ID, B.IPS_IP_ID, B.IPS_SEQ, B.IPS_SOURCE_CODE, B.IPS_NAME, 
  B.IPS_TYPE, B.IPS_SHAPE_TYPE, B.IPS_NE_ID_COLUMN)
WHEN MATCHED THEN
UPDATE SET 
  A.IPS_IP_ID = B.IPS_IP_ID,
  A.IPS_SEQ = B.IPS_SEQ,
  A.IPS_SOURCE_CODE = B.IPS_SOURCE_CODE,
  A.IPS_NAME = B.IPS_NAME,
  A.IPS_TYPE = B.IPS_TYPE,
  A.IPS_SHAPE_TYPE = B.IPS_SHAPE_TYPE,
  A.IPS_NE_ID_COLUMN = B.IPS_NE_ID_COLUMN;

COMMIT;
